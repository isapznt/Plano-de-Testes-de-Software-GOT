/**
 * Calcula o valor total do carrinho de compras aplicando descontos,
 * regras de frete e validações necessárias.
 * 
 * @param {Array} itens - Lista de objetos representando os produtos [{ preco: number, quantidade: number }]
 * @param {string|null} cupom - Código do cupom de desconto (ex: 'PROMO10')
 * @returns {number} Valor total da compra formatado com duas casas decimais
 */
function calcularTotal(itens, cupom) {
  // Validação inicial: garante que o carrinho é um array válido e não está vazio
  if (!Array.isArray(itens) || itens.length === 0) {
    throw new Error("Carrinho inválido");
  }

  let subtotal = 0;

  // Percorre todos os itens para validar a quantidade/preço e somar o subtotal
  for (let i = 0; i < itens.length; i++) {
    const item = itens[i];

    // Validação de quantidade/preço: lança erro se a quantidade for menor/igual a zero ou preço negativo
    if (item.quantidade <= 0 || item.preco < 0) {
      throw new Error("Carrinho inválido");
    }

    // Acumula o valor do item (preço * quantidade) no subtotal
    subtotal += item.preco * item.quantidade;
  }

  let desconto = 0;

  // Aplicação de desconto: se o cupom for 'PROMO10', concede 10% de desconto no subtotal
  if (cupom === "PROMO10") {
    desconto = subtotal * 0.10;
  }

  // Calcula o valor do subtotal com o desconto aplicado
  const subtotalComDesconto = subtotal - desconto;

  // Definição do frete: R$ 15 padrão, ou R$ 0 (grátis) se o valor com desconto for >= R$ 100
  let frete = 15;
  if (subtotalComDesconto >= 100) {
    frete = 0;
  }

  // Soma o subtotal com desconto ao valor do frete
  const total = subtotalComDesconto + frete;

  // Arredonda para duas casas decimais e converte o resultado final de String para Number
  return Number(total.toFixed(2));
}

// Exporta a função para ser utilizada na suíte de testes (carrinho.test.js)
module.exports = { calcularTotal };